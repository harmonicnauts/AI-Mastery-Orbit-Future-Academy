# Reinforcement_Learning_Maze_Solver
This github contains a simple OpenAi Gym Maze Enviroment and some RL Algorithms to solve it.

## General Info
At now i implemented Q-Learning and Sarsa tabular algorithms, greedy, epsilon greedy, Boltzmann and Boltzmann e greedy policies, and a maze enviroment with OpenAI Gym template.

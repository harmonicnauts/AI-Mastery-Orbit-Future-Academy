from setuptools import setup

setup(name='gym_maze',
      version='0.0.1',
      install_requires=['gym>=0.2.3'])
